package com.java.companymaster;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CompanymasterApplication {

	public static void main(String[] args) {
		SpringApplication.run(CompanymasterApplication.class, args);
	}

}
